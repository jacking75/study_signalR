# Programming ASP.NET Core

Introduction
1.	Why Another (ASP).NET?
2.	The First ASP.NET Core Project 
3.	Bootstrapping ASP.NET MVC
4.	ASP.NET MVC Controllers
5.	ASP.NET MVC Views
6.	The Razor Syntax
7.	Design Considerations
8.	Securing your Application 
9.	Access to Application Data
10.	Designing a Web API
11. Posting Data from the Client Side
12.	Client-side Data Binding
13. Building Device-friendly Views
14.	The ASP.NET Core Runtime Environment
15.	Deploying an ASP.NET Core Application  
16.	Migration and Adoption Strategies

Here on GitHub you find also continuously updated examples on ASP.NET Core SignalR and Bootstrap 4.