﻿//////////////////////////////////////////////////////////////////
//
//   PROGRAMMING ASP.NET CORE
//   Dino Esposito
//   
//   Ch07 - Design Considerations
//   UserSecrets
//  

namespace Ch07.UserSecrets.Application
{
    public class MiscService : IMiscService
    {
    }
}