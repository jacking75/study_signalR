﻿//////////////////////////////////////////////////////////////////
//
//   PROGRAMMING ASP.NET CORE
//   Dino Esposito
//   
//   Ch07 - Design Considerations
//   Except
//  

namespace Ch07.Except.Models
{
    public class ViewModelBase
    {
        public string ApplicationTitle { get; set; }
    }
}