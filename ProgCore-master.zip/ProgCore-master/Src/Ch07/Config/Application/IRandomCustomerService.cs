﻿//////////////////////////////////////////////////////////////////
//
//   PROGRAMMING ASP.NET CORE
//   Dino Esposito
//   
//   Ch07 - Design Considerations
//   Config
//    

namespace Ch07.Config.Application
{
    public interface IRandomCustomerService
    {
        
    }
}