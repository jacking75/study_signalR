﻿//////////////////////////////////////////////////////////////////
//
//   PROGRAMMING ASP.NET CORE
//   Dino Esposito
//   
//   Ch11 - Posting Data from Client-side
//   SimpleForms
//


namespace Ch11.SimpleForms.Models
{
    public class HomeViewModel : ViewModelBase
    {
    }
}