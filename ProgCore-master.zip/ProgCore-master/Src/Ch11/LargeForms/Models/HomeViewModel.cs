﻿//////////////////////////////////////////////////////////////////
//
//   PROGRAMMING ASP.NET CORE
//   Dino Esposito
//   
//   Ch11 - Posting Data from Client-side
//   LargeForms
//


namespace Ch11.LargeForms.Models
{
    public class HomeViewModel : ViewModelBase
    {
    }
}