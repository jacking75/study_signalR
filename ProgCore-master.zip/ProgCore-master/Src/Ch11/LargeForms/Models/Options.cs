﻿//////////////////////////////////////////////////////////////////
//
//   PROGRAMMING ASP.NET CORE
//   Dino Esposito
//   
//   Ch11 - Posting Data from Client-side
//   LargeForms
//

namespace Ch11.LargeForms.Models
{
    public enum Options
    {
        None = 0,
        Add = 1,
        Save = 2,
        Delete = 3
    }
}