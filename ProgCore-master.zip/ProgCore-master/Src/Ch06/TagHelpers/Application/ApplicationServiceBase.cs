﻿//////////////////////////////////////////////////////////////////
//
//   PROGRAMMING ASP.NET CORE
//   Dino Esposito
//   
//   Ch06 - The Razor Syntax 
//   TagHelpers
//

namespace Ch06.TagHelpers.Application
{
    public class ApplicationServiceBase
    {
    }
}