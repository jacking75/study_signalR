﻿//////////////////////////////////////////
//
//   PROGRAMMING ASP.NET CORE
//   Dino Esposito
//   
//   Starter kit
//

namespace Ch06.BsTags.Application
{
    public class ApplicationServiceBase
    {
    }
}