﻿//////////////////////////////////////////////////////////////////
//
//   PROGRAMMING ASP.NET CORE
//   Dino Esposito
//   
//   EXTRAS 
//   Blazor #1 - Country Finder
//

using Microsoft.AspNetCore.Mvc;

namespace CountryFinder.Server.Controllers
{
    public class CountryController : Controller
    {
    }
}
