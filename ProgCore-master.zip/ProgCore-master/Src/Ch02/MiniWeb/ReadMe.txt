﻿Not a Web site.
Launch using MiniWeb from the BUILD menu or IIS Express