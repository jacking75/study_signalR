﻿//////////////////////////////////////////////////////////////////
//
//   PROGRAMMING ASP.NET CORE
//   Dino Esposito
//   
//   Ch04 - ASP.NET MVC Controllers
//   Poco
//

namespace Ch04.Poco.Common
{
    public class MyClass
    {
        public string Title { get; set; }
    }
}
