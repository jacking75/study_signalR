﻿//////////////////////////////////////////////////////////////////
//
//   PROGRAMMING ASP.NET CORE
//   Dino Esposito
//   
//   Ch09 - Access to Application Data
//   AdoNet
// 

using System.Data;

namespace Ch09.AdoNet.Models
{
    public class HomeViewModel  
    {
        public DataTable Records { get; set; }
    }
}