﻿//////////////////////////////////////////////////////////////////
//
//   PROGRAMMING ASP.NET CORE
//   Dino Esposito
//   
//   Ch09 - Access to Application Data
//   AdoNet
// 

namespace Ch09.AdoNet.Common
{
    public class ConnectionStrings  
    {
        public static string ProgCore { get; set; }
    }
}