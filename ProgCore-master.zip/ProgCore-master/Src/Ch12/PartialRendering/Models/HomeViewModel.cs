﻿//////////////////////////////////////////////////////////////////
//
//   PROGRAMMING ASP.NET CORE
//   Dino Esposito
//   
//   Ch12 - Client-side data binding
//   PartialRendering
//


namespace Ch12.PartialRendering.Models
{
    public class HomeViewModel : ViewModelBase
    {
    }
}