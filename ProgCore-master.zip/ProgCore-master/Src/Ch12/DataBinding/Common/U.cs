﻿//////////////////////////////////////////////////////////////////
//
//   PROGRAMMING ASP.NET CORE
//   Dino Esposito
//   
//   Ch12 - Client-side data binding
//   DataBinding
//

namespace Ch12.DataBinding.Common
{
    public class U
    {
        public class PartialViews
        {
            public const string ListOfCountries = "_pv_ListOfCountries";
        }
    }
}