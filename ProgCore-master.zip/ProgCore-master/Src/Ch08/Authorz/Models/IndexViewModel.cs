﻿//////////////////////////////////////////////////////////////////
//
//   PROGRAMMING ASP.NET CORE
//   Dino Esposito
//   
//   Ch08 - Securing the Application
//   Authorz
// 

namespace Ch08.Authorz.Models
{
    public class IndexViewModel : ViewModelBase
    {
        public IndexViewModel(string title) : base(title)
        {

        }        
    }
}
