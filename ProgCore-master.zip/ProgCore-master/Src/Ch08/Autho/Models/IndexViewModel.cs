﻿//////////////////////////////////////////////////////////////////
//
//   PROGRAMMING ASP.NET CORE
//   Dino Esposito
//   
//   Ch08 - Securing the Application
//   Autho
// 

namespace Ch08.Autho.Models
{
    public class IndexViewModel : ViewModelBase
    {
        public IndexViewModel(string title) : base(title)
        {

        }        
    }
}
