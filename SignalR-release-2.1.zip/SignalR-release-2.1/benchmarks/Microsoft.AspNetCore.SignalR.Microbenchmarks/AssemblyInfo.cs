[assembly: BenchmarkDotNet.Attributes.AspNetCoreBenchmark]
