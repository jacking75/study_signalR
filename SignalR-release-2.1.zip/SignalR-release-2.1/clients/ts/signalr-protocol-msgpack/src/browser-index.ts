// Copyright (c) .NET Foundation. All rights reserved.
// Licensed under the Apache License, Version 2.0. See License.txt in the project root for license information.

// This is where we add any polyfills we'll need for the browser. It is the entry module for browser-specific builds.

export * from "./index";
