// Copyright (c) Microsoft Open Technologies, Inc. All rights reserved.
// Licensed under the Apache License, Version 2.0. See License.txt in the project root for license information.


// This file is auto-generated


#define FileVersion 1,0,0,0
#define FileVersionStr "1.0.0.0\0"
#define ProductVersion 1,0,0,0
#define ProductVersionStr "1.0.0-alpha0\0"
#define PlatformToolset "v141\0"
