ASP.NET Core SignalR C++ Client
========

This folder contains a C++ client for ASP.NET Core SignalR.

**There are no plans to ship this client at this time.**