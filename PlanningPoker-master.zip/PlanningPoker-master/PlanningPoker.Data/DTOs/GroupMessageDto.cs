namespace PlanningPoker.Data.DTOs
{
    public class GroupMessageDto
    {
        public string PlayerName { get; set; }
        public string GroupId { get; set; }
    }
}