# PlanningPoker
This is a proof of concept application to demonstrate how to start developing AspNetCore with SignalR. You can read the recap about the process of developing this demo here https://medium.com/@andrejsabrickis/recap-creating-a-demo-of-real-time-communication-app-using-aspnetcore-signalr-d8ac0afba081

There are a lot of hacks and shortcuts in the code to make it possible to push out a POC version of this app. I'm looking forward to finding some spare time to polish this. And hopefully one day it could be good enough to use for an agile team to estimate their work.
 
Any help, comments, and critique are more than welcome!

## Build status

| Azure Pipelines | CircleCI |
| --------------- | -------- |
| [![Build Status](https://abrickis.visualstudio.com/PlanningPoker/_apis/build/status/AndrejsAbrickis.PlanningPoker)](https://abrickis.visualstudio.com/PlanningPoker/_build/latest?definitionId=7) |[![CircleCI](https://circleci.com/gh/AndrejsAbrickis/PlanningPoker/tree/master.svg?style=svg)](https://circleci.com/gh/AndrejsAbrickis/PlanningPoker/tree/master) |
