module.exports = {
  outputDir: 'wwwroot/public',
  filenameHashing: false
}