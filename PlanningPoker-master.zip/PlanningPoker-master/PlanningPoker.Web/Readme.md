Planning poker is a proof of concept real-time messaging app built on ASP.NET Core SignalR and Vue.js.

See the demo https://signalr-vuejs.azurewebsites.net/

Build Status: [![Build Status](https://abrickis.visualstudio.com/_apis/public/build/definitions/60989baa-15d5-4298-84d7-60f795ad5fa5/5/badge)](https://github.com/AndrejsAbrickis/signalR-vuejs-demo)